import "dotenv/config";
import { z } from "zod";

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  PORT: z.coerce.number().default(4000),
  // Comma-separated for multiple allowed origins (e.g. staging + prod frontends).
  // "http://a.com,http://b.com" -> ["http://a.com", "http://b.com"]
  CORS_ORIGIN: z
    .string()
    .default("http://localhost:3000")
    .transform((value) => value.split(",").map((origin) => origin.trim())),
  LOG_LEVEL: z.enum(["fatal", "error", "warn", "info", "debug", "trace"]).optional(),
  // Only set to true once this actually sits behind a reverse proxy/load balancer
  // (Phase 13) — affects how Fastify derives request.ip.
  TRUST_PROXY: z.coerce.boolean().default(false),
  DATABASE_URL: z.string().url(), // local Postgres for now; swap to Supabase's pooled URL when that project exists
  // Uncommented as each phase wires up the real dependency:
  // SUPABASE_URL: z.string().url(),          // phase 03
  // SUPABASE_SERVICE_ROLE_KEY: z.string(),   // phase 03
  // R2_ACCOUNT_ID: z.string(),               // phase 04
  // R2_ACCESS_KEY_ID: z.string(),
  // R2_SECRET_ACCESS_KEY: z.string(),
  // R2_BUCKET: z.string(),
  // RAZORPAY_KEY_ID: z.string(),             // phase 06
  // RAZORPAY_KEY_SECRET: z.string(),
});

export const env = envSchema.parse(process.env);
